package com.example.md18304.Adapter;
import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import com.example.md18304.DAO.SachDAO;
import com.example.md18304.R;
import com.example.md18304.model.Sach;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class SachAdapter extends RecyclerView.Adapter<SachAdapter.ViewHolder>  {
    private Context context;
    private ArrayList<Sach> list;

    public SachAdapter (Context context, ArrayList<Sach> list){
        this.context=context;
        this.list=list;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=((Activity)context).getLayoutInflater();
        View view=inflater.inflate(R.layout.item_book, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
       holder.txtmasach.setText("ID: " + list.get(position).getMasach());
       holder.txtTensach.setText(list.get(position).getTensach());
       holder.txtGia.setText(String.valueOf(list.get(position).getGiaban()));
       holder.txtTacgia.setText(list.get(position).getTacgia());
       holder.txtTenloai.setText(list.get(position).getTenloai());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txtmasach, txtTensach, txtTacgia, txtGia, txtTenloai;
        ImageView ivEdit, ivDel;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtmasach =itemView.findViewById(R.id.txtmasach);
            txtTensach =itemView.findViewById(R.id.txttensach);
            txtTacgia =itemView.findViewById(R.id.txttacgia);
            txtGia =itemView.findViewById(R.id.txtgiasach);
            txtTenloai =itemView.findViewById(R.id.txttheloai);
            ivEdit =itemView.findViewById(R.id.ivedit);
            ivDel =itemView.findViewById(R.id.ivxoa);



        }
    }


}
