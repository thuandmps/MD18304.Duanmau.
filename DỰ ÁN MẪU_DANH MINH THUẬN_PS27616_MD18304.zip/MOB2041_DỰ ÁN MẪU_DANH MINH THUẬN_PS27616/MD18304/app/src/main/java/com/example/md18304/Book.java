package com.example.md18304;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.md18304.Adapter.SachAdapter;
import com.example.md18304.DAO.SachDAO;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Book extends AppCompatActivity {
    private RecyclerView recyclerViewsach;
    private SachDAO sachDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);
        recyclerViewsach=findViewById(R.id.RecyviewSach);
        FloatingActionButton floatadd=findViewById(R.id.floatadd);
        sachDAO =new SachDAO(this);
        loaddata();
    }
    private void loaddata(){
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerViewsach.setLayoutManager(linearLayoutManager);
        SachAdapter adapter=new SachAdapter(this, sachDAO.getDSsach());
        recyclerViewsach.setAdapter(adapter);
    }
}