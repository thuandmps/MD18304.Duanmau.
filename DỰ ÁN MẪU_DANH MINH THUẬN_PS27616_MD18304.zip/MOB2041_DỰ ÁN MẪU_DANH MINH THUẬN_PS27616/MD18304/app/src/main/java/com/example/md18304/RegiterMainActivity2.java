package com.example.md18304;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.md18304.DAO.NguoidungDAO;
import com.example.md18304.model.Nguoidung;

public class RegiterMainActivity2 extends AppCompatActivity {
    private NguoidungDAO nguoidungDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regiter_main2);
        EditText edtuser=findViewById(R.id.edtuser);
        EditText etdpass=findViewById(R.id.edtpass);
        EditText edtRepass=findViewById(R.id.edtRepas);
        EditText edtName=findViewById(R.id.edtten);
        EditText edtphone=findViewById(R.id.edtsdt);
        EditText edtAddress=findViewById(R.id.edtdiachi);
        Button btnRegiter=findViewById(R.id.btnRegiter);
        Button btnback=findViewById(R.id.btnback);

        nguoidungDAO =new NguoidungDAO(this);

        btnRegiter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String pass=etdpass.getText().toString();
               String Repass=edtRepass.getText().toString();

               if (!pass.equals(Repass)){
                   Toast.makeText(RegiterMainActivity2.this, "Mật khẩu không trùng nhau", Toast.LENGTH_SHORT).show();
               }else {
                   String user=edtuser.getText().toString();
                   String name=edtName.getText().toString();
                   String phone=edtphone.getText().toString();
                   String address=edtAddress.getText().toString();

                   Nguoidung nguoidung=new Nguoidung(name, phone, address, user, pass);
                   boolean check=nguoidungDAO.dangkitaikhoan(nguoidung);
                   if (check){
                       Toast.makeText(RegiterMainActivity2.this, "Đăng kí thành công", Toast.LENGTH_SHORT).show();
                       finish();
                   }else {
                       Toast.makeText(RegiterMainActivity2.this, "Đăng kí thất bại", Toast.LENGTH_SHORT).show();
                   }

               }


            }
        });



    }
}