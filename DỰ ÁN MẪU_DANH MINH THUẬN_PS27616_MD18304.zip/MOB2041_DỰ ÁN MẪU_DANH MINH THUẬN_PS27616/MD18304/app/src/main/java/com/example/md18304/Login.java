package com.example.md18304;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.md18304.DAO.NguoidungDAO;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText edtuser =findViewById(R.id.edtuser);
        EditText edtpassword =findViewById(R.id.edtpassword);
        Button btdangnhap =findViewById(R.id.btdangnhap);
        Button btnRegiter=findViewById(R.id.btndangki);

        NguoidungDAO nguoidungDAO=new NguoidungDAO(this);

        btdangnhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = edtuser.getText().toString();
                String password = edtpassword.getText().toString();
                boolean check = nguoidungDAO.Kiemtradangnhap(user, password);

                if (check){
                    startActivity(new Intent(Login.this,MainActivity.class ));

                }else {
                    Toast.makeText(Login.this, "Tên đăng nhập hoặc mật khẩu không đúng", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnRegiter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this, RegiterMainActivity2.class ));
            }
        });
    }
}