package com.example.md18304;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import com.example.md18304.Adapter.KhachHangAdapter;
import com.example.md18304.model.KhachHang;
import java.util.ArrayList;

public class DSKhachHang extends AppCompatActivity {
    ArrayList<KhachHang> ds = new ArrayList<KhachHang>();
    ListView lv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dskhach_hang);
        lv=findViewById(R.id.lv);
        ds.add(new KhachHang("PS27616", "Danh Minh Thuận", "20/10/2023"));
        ds.add(new KhachHang("PS27852", "Ngô Thừa Ân", "27/11/2023"));
        ds.add(new KhachHang("PS27741", "Lê văn Minh", "28/12/2023"));
        ds.add(new KhachHang("PS28523", "Hồ Xuân Hùng", "11/12/2023"));
        ds.add(new KhachHang("PS27412", "Lý Gia Kiệt", "07/09/2023"));
        ds.add(new KhachHang("PS29658", "Nguyễn Văn Lộc", "20/11/2023"));
        ds.add(new KhachHang("PS27235", "Ngô Văn Hưng", "17/11/2023"));
        ds.add(new KhachHang("PS27428", "Nguyễn Xuân Hùng", "18/10/2023"));

        KhachHangAdapter adapter= new KhachHangAdapter(DSKhachHang.this, ds);
        lv.setAdapter(adapter);
    }
}