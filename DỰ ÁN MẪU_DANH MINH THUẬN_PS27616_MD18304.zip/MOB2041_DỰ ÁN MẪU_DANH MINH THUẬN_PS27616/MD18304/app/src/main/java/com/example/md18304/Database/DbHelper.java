package com.example.md18304.Database;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbHelper extends SQLiteOpenHelper {

    public DbHelper (Context context){
        super(context, "QUANLYTHANHVIEN", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        //loaisach
        String tLoaiSach = "CREATE TABLE LOAISACH (maloai integer primary key autoincrement, tenloai text)";
        db.execSQL(tLoaiSach);
        db.execSQL("INSERT INTO LOAISACH VALUES(1, 'Thiếu nhi'),(2, 'Tình cảm'), (3, 'Hành động')");

        //sach
        String tSach = "CREATE TABLE SACH (masach integer primary key autoincrement, " +
                "tensach text, tacgia text, giaban integer, " +
                "maloai integer references LOAISACH(maloai))";
        db.execSQL(tSach);
        db.execSQL("INSERT INTO SACH VALUES(1, 'Kể cho em nghe', 'Nguyễn Ánh', 15000, 1), (2, 'Trạng Quỳnh', 'Kim Đồng', 5000,1)");


        //nguoidung
        String tNGuoiDung = "CREATE TABLE NGUOIDUNG (manguoidung integer primary key autoincrement, tennguoidung text, " +
                "sdt text, diachi text, tendangnhap text, matkhau text, role text)";
        db.execSQL(tNGuoiDung);
        db.execSQL("INSERT INTO NGUOIDUNG VALUES(1, 'Nguyễn Văn Anh', '0987654321', 'Q12 TP.HCM', 'vananh01', '123456', 1)," +
                "(2, 'Trịnh Hòa Bình', '0987162323','Q9 TP.HCM', 'hoabinh01', '111222', 2)," +
                "(3, 'Lê Văn Hùng', '082318912','Q6 TP.HCM', 'hunglv01', '12341234', 3)");



        //phieumuon
        String tPhieuMuon = "CREATE TABLE PHIEUMUON (maphieumuonn integer primary key autoincrement, ngaymuon text, ngaytra text, mand integer  references NGUOIDUNG(mand))";
        db.execSQL(tPhieuMuon);
        db.execSQL("INSERT INTO PHIEUMUON VALUES(1, '20/09/2023', '26/09/2023', 1)");



        //ctpm
        String tCTPM = "CREATE TABLE CTPM(mactpm integer primary key autoincrement, " +
                "mapm integer references PHIEUMUON(mapm), masach integer references SACH(masach), soluong integer)";
        db.execSQL(tCTPM);
        db.execSQL("INSERT INTO CTPM VALUES(1, 1, 1, 2),(2, 1, 2, 1)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        if(i != i1){
            db.execSQL("DROP TABLE IF EXISTS LOAISACH");
            db.execSQL("DROP TABLE IF EXISTS SACH");
            db.execSQL("DROP TABLE IF EXISTS NGUOIDUNG");
            db.execSQL("DROP TABLE IF EXISTS NGUOIDDUNG");
            db.execSQL("DROP TABLE IF EXISTS CTPM");
            onCreate(db);
        }

    }
}
