package com.example.md18304.model;

public class KhachHang {

    public String ma;
    public String ten;

    public String ngaymuon;



    public KhachHang (String ma, String ten, String ngaymuon){
        this.ma=ma;
        this.ten=ten;
        this.ngaymuon=ngaymuon;
    }
}
