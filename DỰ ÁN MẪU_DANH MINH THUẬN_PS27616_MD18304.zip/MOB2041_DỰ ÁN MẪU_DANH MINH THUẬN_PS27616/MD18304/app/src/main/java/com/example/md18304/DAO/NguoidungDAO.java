package com.example.md18304.DAO;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.example.md18304.Database.DbHelper;
import com.example.md18304.model.Nguoidung;

public class NguoidungDAO {

    private DbHelper dbHelper;
    SharedPreferences sharedPreferences;

    public NguoidungDAO(Context context) {
        dbHelper = new DbHelper(context);
        sharedPreferences =context.getSharedPreferences("dataUser", Context.MODE_PRIVATE);

    }
    public boolean Kiemtradangnhap (String username, String password){
        SQLiteDatabase sqLiteDatabase=dbHelper.getReadableDatabase();
        Cursor cursor=sqLiteDatabase.rawQuery("SELECT * FROM NGUOIDUNG WHERE tendangnhap = ? AND matkhau = ?", new String[]{username, password});

        if (cursor.getCount() > 0){
            cursor.moveToFirst();
            SharedPreferences .Editor editor=sharedPreferences.edit();
            editor.putInt("role", cursor.getInt(6));
            editor.apply();
        }

        if(cursor.getCount() > 0){
            return true;
        }else {
            return false;
        }
        //return cursor.getCount() > 0;
    }
    public boolean dangkitaikhoan(Nguoidung nguoidung){
        SQLiteDatabase sqLiteDatabase=dbHelper.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("tennguoidung", nguoidung.getTennguoidung());
        contentValues.put("sdt", nguoidung.getSdt());
        contentValues.put("diachi", nguoidung.getDiachi());
        contentValues.put("tendangnhap", nguoidung.getTendangnhap());
        contentValues.put("matkhau", nguoidung.getMatkhau());
        contentValues.put("role", 1);

        long check=sqLiteDatabase.insert("NGUOIDUNG", null, contentValues);
        return check != -1;

    }
}
