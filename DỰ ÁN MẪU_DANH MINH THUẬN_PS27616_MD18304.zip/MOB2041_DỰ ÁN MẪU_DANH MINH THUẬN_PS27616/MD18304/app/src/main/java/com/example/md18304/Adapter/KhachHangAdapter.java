package com.example.md18304.Adapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.example.md18304.DSKhachHang;
import com.example.md18304.R;
import com.example.md18304.model.KhachHang;
import java.util.ArrayList;
import java.util.prefs.BackingStoreException;

public class KhachHangAdapter extends BaseAdapter {
    Context c;
    ArrayList<KhachHang> ds;

    public KhachHangAdapter(Context c, ArrayList<KhachHang> ds){
        this.c=c;
        this.ds=ds;
    }

    @Override
    public int getCount() {
        return ds.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int i, View View, ViewGroup parent) {
        LayoutInflater inf=((DSKhachHang)c).getLayoutInflater();
        View =inf.inflate(R.layout.one_item_dskh, null);
        TextView tv_ma=View.findViewById(R.id.tvma);
        TextView tv_ten=View.findViewById(R.id.tvten);
        TextView tv_diachi=View.findViewById(R.id.tvdiachi);
        tv_ma.setText(ds.get(i).ma);
        tv_ten.setText(ds.get(i).ten);
        tv_diachi.setText(ds.get(i).ngaymuon);
        return View;
    }
}
