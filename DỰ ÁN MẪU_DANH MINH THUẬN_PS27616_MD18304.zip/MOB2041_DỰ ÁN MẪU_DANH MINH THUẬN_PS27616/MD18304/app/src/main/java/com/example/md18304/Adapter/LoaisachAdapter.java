package com.example.md18304.Adapter;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.md18304.DAO.LoaisachDAO;
import com.example.md18304.R;
import com.example.md18304.model.Loaisach;
import java.util.ArrayList;

public class LoaisachAdapter extends RecyclerView.Adapter<LoaisachAdapter.ViewHolder>{
    private Context context;
    private ArrayList<Loaisach> list;

    private LoaisachDAO loaisachDAO;

    public LoaisachAdapter(Context context, ArrayList<Loaisach> list, LoaisachDAO loaisachDAO){
       this.context=context;
       this.list=list;
       this.loaisachDAO=loaisachDAO;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=((Activity)context).getLayoutInflater();
        View view=inflater.inflate(R.layout.item_catelogi, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
      holder.txtmaloai.setText("ID: " + list.get(position).getMaloai());
      holder.txttenloai.setText(list.get(position).getTenloai());

      holder.ivedit.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              showDialogUpdate(list.get(holder.getAdapterPosition()));
          }
      });

      holder.ivxoa.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              AlertDialog.Builder builder=new AlertDialog.Builder(context);
              builder.setTitle("THÔNG BÁO");
              builder.setMessage("Bạn có muốn chắc chắn xóa không " + list.get(holder.getAdapterPosition()).getTenloai() + "Không");
              builder.setIcon(R.drawable.baseline_warning_24);
              builder.setPositiveButton("Có", new DialogInterface.OnClickListener() {
                  @Override
                  public void onClick(DialogInterface dialog, int which) {
                      int check=loaisachDAO.xoaLoaisach(list.get(holder.getAdapterPosition()).getMaloai());
                      switch (check){
                          case -1:
                              Toast.makeText(context, "Xóa thất bại", Toast.LENGTH_SHORT).show();
                              break;
                          case 0:
                              Toast.makeText(context, "Bạn cần xóa các cuốn sách trong thể loại này trước", Toast.LENGTH_SHORT).show();
                              break;
                          case 1:
                              Toast.makeText(context, "Xóa thành công", Toast.LENGTH_SHORT).show();
                              loadData();
                              break;
                      }
                  }
              });
              builder.setNegativeButton("Không", null);
              AlertDialog alertDialog=builder.create();
              alertDialog.show();

          }
      });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView txttenloai, txtmaloai;
        private ImageView ivxoa, ivedit;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtmaloai =itemView.findViewById(R.id.txtmaloai);
            txttenloai =itemView.findViewById(R.id.txttenloai);
            ivxoa =itemView.findViewById(R.id.ivxoa);
            ivedit =itemView.findViewById(R.id.ivedit);
        }
    }

    private void showDialogUpdate(Loaisach loaisach){
        AlertDialog.Builder builder=new AlertDialog.Builder(context);
        LayoutInflater layoutInflater=((Activity)context).getLayoutInflater();
        View view=layoutInflater.inflate(R.layout.dialog_catelogi, null);
        builder.setView(view);
        AlertDialog alertDialog=builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        alertDialog.setCancelable(false);
        alertDialog.show();

        TextView txtTieuDe =view.findViewById(R.id.txtTieuDe);
        EditText edtTenloai =view.findViewById(R.id.edtTenloai);
        Button btnLuu=view.findViewById(R.id.btnLuu);
        Button btnHuy=view.findViewById(R.id.btnHuy);

        txtTieuDe.setText("Cập nhật");
        btnLuu.setText("Cập nhật");
        edtTenloai.setText(loaisach.getTenloai());

        btnLuu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String tenLoai=edtTenloai.getText().toString();
               Loaisach loaisachUpdate=new Loaisach(loaisach.getMaloai(), tenLoai);
               boolean check=loaisachDAO.suaLoaisach(loaisachUpdate);
               if (check){
                   Toast.makeText(context, "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                   loadData();
                   alertDialog.dismiss();
               }else {
                   Toast.makeText(context, "Cập nhật không thành công", Toast.LENGTH_SHORT).show();
               }
            }
        });

        btnHuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

    }

    private void loadData(){
        list.clear();
        list=loaisachDAO.getDSLoaisach();
        notifyDataSetChanged();
    }

}

