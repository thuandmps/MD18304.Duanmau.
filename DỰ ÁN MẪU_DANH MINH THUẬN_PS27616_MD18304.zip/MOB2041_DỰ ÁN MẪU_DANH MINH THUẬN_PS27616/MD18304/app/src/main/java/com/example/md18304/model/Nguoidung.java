package com.example.md18304.model;

public class Nguoidung {
    private  int manguoidung;
    private  String tennguoidung;
    private String sdt;
    private String diachi;
    private String tendangnhap;
    private String matkhau;
    private int role;

    public Nguoidung(int manguoidung, String tennguoidung, String sdt, String diachi, String tendangnhap, String matkhau, int role) {
        this.manguoidung = manguoidung;
        this.tennguoidung = tennguoidung;
        this.sdt = sdt;
        this.diachi = diachi;
        this.tendangnhap = tendangnhap;
        this.matkhau = matkhau;
        this.role = role;
    }

    public Nguoidung(String tennguoidung, String sdt, String diachi, String tendangnhap, String matkhau) {
        this.tennguoidung = tennguoidung;
        this.sdt = sdt;
        this.diachi = diachi;
        this.tendangnhap = tendangnhap;
        this.matkhau = matkhau;
    }

    public int getManguoidung() {
        return manguoidung;
    }

    public void setManguoidung(int manguoidung) {
        this.manguoidung = manguoidung;
    }

    public String getTennguoidung() {
        return tennguoidung;
    }

    public void setTennguoidung(String tennguoidung) {
        this.tennguoidung = tennguoidung;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getDiachi() {
        return diachi;
    }

    public void setDiachi(String diachi) {
        this.diachi = diachi;
    }

    public String getTendangnhap() {
        return tendangnhap;
    }

    public void setTendangnhap(String tendangnhap) {
        this.tendangnhap = tendangnhap;
    }

    public String getMatkhau() {
        return matkhau;
    }

    public void setMatkhau(String matkhau) {
        this.matkhau = matkhau;
    }

    public int getRole() {
        return role;
    }

    public void setRole(int role) {
        this.role = role;
    }
}
