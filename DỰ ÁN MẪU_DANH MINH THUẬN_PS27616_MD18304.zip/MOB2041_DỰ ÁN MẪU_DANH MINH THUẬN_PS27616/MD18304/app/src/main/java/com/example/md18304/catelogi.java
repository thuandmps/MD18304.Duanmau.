package com.example.md18304;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.example.md18304.Adapter.LoaisachAdapter;
import com.example.md18304.DAO.LoaisachDAO;
import com.example.md18304.model.Loaisach;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import java.util.ArrayList;

public class catelogi extends AppCompatActivity {
    private LoaisachDAO loaisachDAO;
    private RecyclerView recyclerViewCatelori;
    private ArrayList<Loaisach> list;

    private RelativeLayout relativeloaisach;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catelogi);

        recyclerViewCatelori = findViewById(R.id.recylerviewloaisach);
        FloatingActionButton floatadd = findViewById(R.id.floatadd);
        relativeloaisach = findViewById(R.id.relativeLoaisach);

        floatadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showdialogthem();
            }
        });
        //data
        loaisachDAO = new LoaisachDAO(this);
        loadData();
    }

    private void loadData() {
        recyclerViewCatelori = findViewById(R.id.recylerviewloaisach);
        list = loaisachDAO.getDSLoaisach();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerViewCatelori.setLayoutManager(linearLayoutManager);
        LoaisachAdapter loaisachAdapter = new LoaisachAdapter(this, list, loaisachDAO);
        recyclerViewCatelori.setAdapter(loaisachAdapter);
    }

    private void showdialogthem() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_catelogi, null);
        builder.setView(view);

        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        alertDialog.setCancelable(false);
        alertDialog.show();

        EditText edttenloai = view.findViewById(R.id.edtTenloai);
        Button btnLuu = view.findViewById(R.id.btnLuu);
        Button btnhuy = view.findViewById(R.id.btnHuy);
        CardView cardView = view.findViewById(R.id.Cardviewdialog);

        btnLuu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String tenLoai = edttenloai.getText().toString();
                if (tenLoai.equals("")) {
                    //Toast.makeText(catelogi.this, "Nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                    showNoti(cardView, "Nhập đầy đủ thông tin");
                    return;
                }
                boolean check = loaisachDAO.Themloaisach(tenLoai);

                if (check) {
                    //Toast.makeText(catelogi.this, "Thêm thành công", Toast.LENGTH_SHORT).show();
                    Snackbar.make(recyclerViewCatelori,"Thêm thành công", Snackbar.LENGTH_SHORT).show();
                    //showNoti(relativeloaisach, "Thêm thành công");
                    loadData();
                    alertDialog.dismiss();
                } else {
                    Toast.makeText(catelogi.this, "Thêm thất bại", Toast.LENGTH_SHORT).show();
                    //showNoti(relativeloaisach, "Thêm thất bại");
                }
            }
        });

        btnhuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
    }

    private void showNoti(View view, String message) {
        Snackbar.make(view, message, Snackbar.LENGTH_SHORT)
                .setAction("OK", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                    }
                }).show();
    }
}
