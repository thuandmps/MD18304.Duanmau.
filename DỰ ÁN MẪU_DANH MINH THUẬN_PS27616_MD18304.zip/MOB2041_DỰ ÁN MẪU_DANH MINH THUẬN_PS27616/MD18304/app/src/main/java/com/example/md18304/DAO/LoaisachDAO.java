package com.example.md18304.DAO;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.example.md18304.Database.DbHelper;
import com.example.md18304.catelogi;
import com.example.md18304.model.Loaisach;
import java.util.ArrayList;

public class LoaisachDAO {
    private DbHelper dbHelper;
    public LoaisachDAO(Context context){
        dbHelper=new DbHelper(context);
    }

    public ArrayList<Loaisach> getDSLoaisach(){
        ArrayList<Loaisach> list = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase=dbHelper.getReadableDatabase();
        Cursor cursor=sqLiteDatabase.rawQuery("SELECT * FROM LOAISACH", null);
        if(cursor.getCount() > 0 ){
            cursor.moveToFirst();
            do{
                list.add(new Loaisach(cursor.getInt(0), cursor.getString(1)));
            }while (cursor.moveToNext());
        }

        return list;
    }

    public boolean Themloaisach(String tenLoai){
        SQLiteDatabase sqLiteDatabase=dbHelper.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("tenloai", tenLoai);
        long check=sqLiteDatabase.insert("LOAISACH", null, contentValues);
        if ( check== -1){
            return false;
        }else {
            return true;
        }
        //return check != -1;

    }

    public boolean suaLoaisach(Loaisach loaisach){
        SQLiteDatabase sqLiteDatabase=dbHelper.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("tenloai", loaisach.getTenloai());
        int check=sqLiteDatabase.update("LOAISACH", contentValues, "maloai = ?", new String[]{String.valueOf(loaisach.getMaloai())});
        return check != 0;
    }

    public int xoaLoaisach(int maloai){
        SQLiteDatabase sqLiteDatabase=dbHelper.getWritableDatabase();


        //kiem tra su ton tai cua nhung cuon sach trong bang sach voi the loai fang thuc hien xoa
        Cursor cursor=sqLiteDatabase.rawQuery("SELECT * FROM SACH WHERE maloai = ?", new String[]{String.valueOf(maloai)});
        if(cursor.getCount() > 0){
            return 0;//khong dc xoa vi rang buoc khoa ngoai
        }else {
            int check=sqLiteDatabase.delete("LOAISACH", "maloai = ?", new String[]{String.valueOf(maloai)});
            if (check==0){
                return  -1;//xoa kg dc vi loi he thong
            }else {
                return 1;
            }
        }
    }
}
