package com.example.md18304;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LinearLayout linerloaisach=findViewById(R.id.linerloaisach);
        LinearLayout linersach=findViewById(R.id.linersach);
        LinearLayout linerPM=findViewById(R.id.linerPM);
        LinearLayout linerdskh=findViewById(R.id.linerdskh);
        LinearLayout linerthongke=findViewById(R.id.linerThongke);
        LinearLayout linerLSMS=findViewById(R.id.linerLSMS);


        //lay role da luu trong sharepresen
        SharedPreferences sharedPreferences=getSharedPreferences("dataUser", MODE_PRIVATE);
        int role=sharedPreferences.getInt("role", -1);

        switch (role){
            case 1://nguoidung
                linerloaisach.setVisibility(View.GONE);
                linersach.setVisibility(View.GONE);
                linerthongke.setVisibility(View.GONE);
                linerPM.setVisibility(View.GONE);
                break;
            case 2:
                linerloaisach.setVisibility(View.GONE);
                linersach.setVisibility(View.GONE);
                linerthongke.setVisibility(View.GONE);
                linerLSMS.setVisibility(View.GONE);
                break;

            case 3:
                linerLSMS.setVisibility(View.GONE);
                break;
            default:
                linerloaisach.setVisibility(View.GONE);
                linersach.setVisibility(View.GONE);
                linerthongke.setVisibility(View.GONE);
                linerLSMS.setVisibility(View.GONE);
                linerPM.setVisibility(View.GONE);
                break;
        }

        linerloaisach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             startActivity(new Intent(MainActivity.this, catelogi.class));
            }
        });

        linersach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Book.class));
            }
        });

        linerdskh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, DSKhachHang.class));
            }
        });




    }
}